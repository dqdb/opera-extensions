This folder containts user JS files.
